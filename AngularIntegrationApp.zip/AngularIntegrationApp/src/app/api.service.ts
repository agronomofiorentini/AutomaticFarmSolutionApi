import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'https://www.api.automaticfarmsolutionwebapp.com/'; // Sostituisci con l'URL base dell'API

  constructor(private http: HttpClient) {}

  sendGeoJSONFile(geoJSON: any): Observable<any> {
    const username = 'XXXXXXXXXXXXXXX';
    const password = 'XXXXXXXXXXXXXXX';

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Basic ' + btoa(username + ':' + password)
    });

    //return this.http.post<any>(`${this.baseUrl}/AFS/EvapotraspirationMapGeojson?`, geoJSON, { headers });
    //return this.http.post<any>(`${this.baseUrl}/AFS/ForecastVineyardGeojson`, geoJSON, { headers });
    //return this.http.post<any>(`${this.baseUrl}/AFS/VegetationIndexGeojson?vegetationindex=ndvi`, geoJSON, { headers });
    return this.http.post<any>(`${this.baseUrl}/AFS/AutoPrescriptionMapGEOjson?AutoPrescription=False&NumberZone=3&userfertilizer=200&Strategy=highwherehigh&ProductType=Solid&ProductName=Urea&GeographicReference=WGS84`, geoJSON, { headers });
   

  }
}
