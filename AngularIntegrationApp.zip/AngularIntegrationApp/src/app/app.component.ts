import { Component } from '@angular/core';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  template: `
    <button (click)="sendGeoJSON()">Invia GeoJSON</button>
    <pre *ngIf="response">{{ response | json }}</pre>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  response: any;

  constructor(private apiService: ApiService) {}

  sendGeoJSON() { 

    const geoJSON = {"type":"FeatureCollection","features":[{"type":"Feature","properties":{"_leaflet_id":433,"feature_type":"polygon"},"geometry":{"type":"Polygon","coordinates":[[[13.3888,43.6117],[13.3892,43.6104],[13.3913,43.6106],[13.3919,43.6108],[13.393,43.6108],[13.394,43.6108],[13.3952,43.611],[13.3961,43.6111],[13.3965,43.6116],[13.397,43.612],[13.3963,43.6122],[13.3955,43.6124],[13.3951,43.6123],[13.3949,43.6127],[13.3946,43.6127],[13.3946,43.6123],[13.3942,43.6121],[13.394,43.6121],[13.3936,43.6122],[13.393,43.6121],[13.3927,43.6123],[13.3923,43.6124],[13.3912,43.6121],[13.3888,43.6117]]]}}]};

    this.apiService.sendGeoJSONFile(geoJSON).subscribe(response => {
      this.response = response;
      console.log('Risposta:', response);
    });
  }
}
