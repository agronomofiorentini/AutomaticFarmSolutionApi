from django.shortcuts import render
from django.http import HttpResponse
import requests
import json

def upload_view(request):
    if request.method == 'POST':

        API_URL="https://www.api.automaticfarmsolutionwebapp.com/AFS/VegetationIndexHtmlWidget?vegetationindex=ndvi"

        # Set the path to the geojson
        geojson = "county.geojson"

        # Ottenere i dati dell'autenticazione
        USERNAME="XXXXXXXXXXXX"
        PASSWORD="XXXXXXXXXXXX"

        # Set the authentication header
        auth_data = {
            "username": USERNAME,
            "password": PASSWORD
        }

        # Read the content of geojson
        with open(geojson, "r") as file:
            geojson_data = json.load(file)

        # Make the POST request
        response = requests.post(API_URL, json=geojson_data, auth=(auth_data["username"], auth_data["password"]))
       
        return render(request,'upload.html',{'html': response.content.decode("utf-8")})

    return render(request, 'upload.html')  # Creare il template 'upload.html'
